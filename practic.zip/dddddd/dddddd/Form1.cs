﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dddddd
{
    public partial class Form1 : Form
    {
        string connectionString = @"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=11.8.accdb;";

        public Form1()
        {
            InitializeComponent();
            LoadData();
        }

        private void LoadData()
        {
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                OleDbDataAdapter adapter = new OleDbDataAdapter("SELECT * FROM Clients", conn);
                DataTable table = new DataTable();
                adapter.Fill(table);
                dataGridView1.DataSource = table;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (OleDbConnection conn = new OleDbConnection(connectionString))
            {
                conn.Open();
                string query = "INSERT INTO this.клиентTableAdapter.Fill(this._11_8DataSet.Клиент); (Имя, Фамилия, Email, Телефон, ДатаРождения, ДатаРегистрации) VALUES (@name, @surname, @email, @phone, @dob, @registrationDate)";
                using (OleDbCommand cmd = new OleDbCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@name", textBoxName.Text);
                    cmd.Parameters.AddWithValue("@surname", textBoxSurname.Text);
                    cmd.Parameters.AddWithValue("@email", textBoxEmail.Text);
                    cmd.Parameters.AddWithValue("@phone", textBoxPhone.Text);
                    cmd.Parameters.AddWithValue("@dob", dateTimePickerDOB.Value);
                    cmd.Parameters.AddWithValue("@registrationDate", DateTime.Now);
                    cmd.ExecuteNonQuery();
                }
            }
            LoadData();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                int clientId = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells[0].Value);
                using (OleDbConnection connection = new OleDbConnection(connectionString))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand("DELETE FROM Clients WHERE ClientID = @ClientID", connection);
                    command.Parameters.AddWithValue("@ClientID", clientId);
                    command.ExecuteNonQuery();
                }
                LoadData();
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_11_8DataSet1.Заказ". При необходимости она может быть перемещена или удалена.
            this.заказTableAdapter1.Fill(this._11_8DataSet1.Заказ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_11_8DataSet.Сотрудник". При необходимости она может быть перемещена или удалена.
            this.сотрудникTableAdapter.Fill(this._11_8DataSet.Сотрудник);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_11_8DataSet.Меню". При необходимости она может быть перемещена или удалена.
            this.менюTableAdapter.Fill(this._11_8DataSet.Меню);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_11_8DataSet.Заказ". При необходимости она может быть перемещена или удалена.
            this.заказTableAdapter.Fill(this._11_8DataSet.Заказ);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "_11_8DataSet.Клиент". При необходимости она может быть перемещена или удалена.
            this.клиентTableAdapter.Fill(this._11_8DataSet.Клиент);

        }
    }
}
